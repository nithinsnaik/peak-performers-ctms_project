 <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>developed by &copy; Peak Performers</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->